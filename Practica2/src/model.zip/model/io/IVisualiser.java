package model.io;
/**
 * Interfaz IVisualiser
 * @author Nikita Polyanskiy P550048833
 *
 */
public interface IVisualiser {
	/**
	 * Metodo show
	 */
	public void show();
	/**
	 * metodo close
	 */
	public void close();
}
