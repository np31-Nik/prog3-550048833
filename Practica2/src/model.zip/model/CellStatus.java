package model;
/**
 * 
 * @author Nikita Polyanskiy 550048833
 *
 */

/**
 * Enum CellStatus.
 *
 */
public enum CellStatus {
	/**
	 * Tipos de estado de la celda
	 */
	WATER,HIT,DESTROYED;
}
