package model;

/**
 * 
 * @author Nikita Polyanskiy 550048833
 *
 */

/**
 * Enum Orientation.
 *
 */
public enum Orientation {
	/**
	 * Tipos de orientacion posibles
	 */
	NORTH,EAST,SOUTH,WEST;
}
